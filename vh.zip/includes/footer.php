<!-- FontAwesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- Footer -->
<footer class="bg-black border-t border-white/10 py-10 mt-16">
  <div class="mx-auto max-w-7xl px-6 lg:px-8 text-white/70">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
      <div>
        <h2 class="text-lg font-semibold text-white mb-3">VelocityHost.tn</h2>
        <p class="text-sm leading-6">Premium Game Hosting – Your Privacy is our Priority.</p>
      </div>
      <div>
        <h3 class="text-sm font-semibold text-white mb-3">Quick Links</h3>
        <ul class="space-y-2">
          <li><a href="index.php" class="hover:text-blue-400">Home</a></li>
          <li><a href="index.php#pricing" class="hover:text-blue-400">Game Hosting</a></li>
          <li><a href="rdp.php" class="hover:text-blue-400">Windows Server</a></li>
          <li><a href="dedicated.php" class="hover:text-blue-400">Dedicated Servers</a></li>
        </ul>
      </div>
      <div>
        <h3 class="text-sm font-semibold text-white mb-3">Legal</h3>
        <ul class="space-y-2">
          <li><a href="pletx.php" class="hover:text-blue-400">DDoS Protection</a></li>
          <li><a href="terms-of-service.php" class="hover:text-blue-400">Terms of Service</a></li>
          <li><a href="privacy-policy.php" class="hover:text-blue-400">Privacy Policy</a></li>
          <li><a href="https://status.velocityhost.tn" class="hover:text-blue-400">Status</a></li>
        </ul>
      </div>
      <div>
        <h3 class="text-sm font-semibold text-white mb-3">Follow Us</h3>
        <div class="flex space-x-4">
          <a href="https://www.instagram.com/vlsho.host/" class="hover:text-blue-400"><i class="fab fa-instagram"></i></a>
          <a href="https://discord.com/invite/kKJWH95HnJ" class="hover:text-blue-400"><i class="fab fa-discord"></i></a>
          <a href="https://www.youtube.com/@VelocityHost/" class="hover:text-blue-400"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
    <div class="mt-8 border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between text-sm text-white/50">
      <p>© <span id="year"></span> VelocityHost.tn — All rights reserved.</p>
      <p>Built with ❤️ for Gamers</p>
    </div>
  </div>
</footer>