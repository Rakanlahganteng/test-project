  <!-- Navbar -->
  <header class="sticky top-0 z-50 bg-black/70 backdrop-blur-md shadow-md">
    <div class="mx-auto max-w-7xl px-6 lg:px-12">
      <nav class="flex items-center justify-between py-5 relative">

        <!-- Logo -->
        <a href="index.php" class="flex items-center gap-4 group" aria-label="VelocityHost">
          <span
            class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 shadow-glow transition-all duration-500 group-hover:scale-110 overflow-hidden">
            <img src="assets/imgs/velocityhost.png" alt="VelocityHost Logo"
              class="h-30 w-30 object-contain animate-bounce">
          </span>
          <span
            class="text-2xl font-extrabold tracking-tight text-white transition-colors duration-300 group-hover:text-brand-500">VelocityHost</span>
        </a>

        <!-- Desktop Links -->
        <div class="hidden md:flex items-center gap-10 text-white/80 font-medium text-lg relative">
          <a href="index.php" class="relative group px-2 py-1">
            Home
            <span class="absolute left-0 -bottom-1 w-0 h-0.5 bg-brand-500 transition-all group-hover:w-full"></span>
          </a>

          <!-- Store Dropdown -->
          <div class="relative group">
            <button
              class="relative px-2 py-1 flex items-center gap-1 group-hover:text-brand-500 transition-colors duration-300">
              Store
              <svg class="h-4 w-4 mt-1 transition-transform duration-300 group-hover:rotate-180"
                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <div
              class="absolute left-0 mt-2 w-48 bg-black/90 backdrop-blur-md rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
              <ul class="flex flex-col py-2">
                <li><a href="index.php#pricing"
                    class="block px-4 py-2 hover:bg-white/10 transition-all rounded-tl-xl rounded-tr-xl">Game
                    Servers</a></li>
                <li><a href="rdp.php" class="block px-4 py-2 hover:bg-white/10 transition-all">Windows Servers</a></li>
                <li><a href="vps.php" class="block px-4 py-2 hover:bg-white/10 transition-all">VPS Servers</a></li>
                <li><a href="dedicated.php" class="block px-4 py-2 hover:bg-white/10 transition-all">Dedicated Servers</a></li>
              </ul>
            </div>
          </div>

          <a href="http://status.velocityhost.tn/" class="relative group px-2 py-1">
            Status
            <span class="absolute left-0 -bottom-1 w-0 h-0.5 bg-brand-500 transition-all group-hover:w-full"></span>
          </a>
          <a href="ping.php" class="relative group px-2 py-1">
            Ping
            <span class="absolute left-0 -bottom-1 w-0 h-0.5 bg-brand-500 transition-all group-hover:w-full"></span>
          </a>

          <!-- About Us Dropdown -->
          <div class="relative group">
            <button
              class="relative px-2 py-1 flex items-center gap-1 group-hover:text-brand-500 transition-colors duration-300">
              About Us
              <svg class="h-4 w-4 mt-1 transition-transform duration-300 group-hover:rotate-180"
                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <div
              class="absolute left-0 mt-2 w-48 bg-black/90 backdrop-blur-md rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
              <ul class="flex flex-col py-2">
                <li><a href="pletx.php"
                    class="block px-4 py-2 hover:bg-white/10 transition-all rounded-tl-xl rounded-tr-xl">DDoS Protection</a>
                </li>
                <li><a href="terms-of-service.php" class="block px-4 py-2 hover:bg-white/10 transition-all">Terms Of Service</a>
                </li>
                <li><a href="privacy-policy.php"
                    class="block px-4 py-2 hover:bg-white/10 transition-all rounded-bl-xl rounded-br-xl">Privacy Policy</a>
                </li>
                <li><a href="comparison.php"
                    class="block px-4 py-2 hover:bg-white/10 transition-all rounded-bl-xl rounded-br-xl">Comparison</a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- Buttons -->
        <div class="hidden md:flex items-center gap-4">
          <a href="https://velocityhost.tn/store/login.php"
            class="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-sm font-semibold transition-all duration-300 hover:scale-105">Login</a>
          <a href="https://velocityhost.tn/store/register.php"
            class="px-5 py-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-sm font-semibold shadow-glow transition-all duration-300 hover:scale-105">Register</a>
        </div>

        <!-- Mobile Hamburger -->
        <div class="md:hidden flex items-center">
          <button id="mobile-menu-button" class="text-white focus:outline-none">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"
              stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </nav>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="hidden md:hidden bg-black/90 backdrop-blur-md">
      <a href="index.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Home</a>
      <a href="index.php#pricing" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Game Servers</a>
      <a href="rdp.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Windows Servers</a>
      <a href="rdp.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">VPS Servers</a>
      <a href="dedicated.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Dedicated Servers</a>
      <a href="http://status.velocityhost.tn/" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Status</a>
      <a href="ping.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Ping</a>
      <a href="terms-of-service.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Terms Of Service</a>
      <a href="privacy-policy.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Privacy Policy</a>
      <a href="comparison.php" class="block px-6 py-3 text-white hover:bg-white/10 transition-all">Comparison</a>
      <a href= "https://velocityhost.tn/store/login.php"
        class="block px-6 py-3 bg-white/10 text-black rounded-xl m-4 text-center hover:bg-white/20 transition-all">Login</a>
      <a href= "https://velocityhost.tn/store/register.php"
        class="block px-6 py-3 bg-brand-500 text-black rounded-xl m-4 text-center hover:bg-brand-600 transition-all">Register</a>
    </div>
  </header>

  <script>
    const menuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    menuButton.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  </script>



  <!-- TailwindCSS custom colors (add in your config if needed) -->
  <style>
    .from-brand-500 {
      --tw-gradient-from: #4f46e5;
    }

    .to-brand-700 {
      --tw-gradient-to: #3730a3;
    }

    .shadow-glow {
      box-shadow: 0 0 15px rgba(79, 70, 229, 0.5);
    }
  </style>